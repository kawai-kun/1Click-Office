﻿; =====================================================================
; Script Inno Setup 7 cho Bộ Add-in Office: 1Click Enterprise (Word & Excel)
; Phiên bản: 3.0 Enterprise
; Tác giả: Trần Quốc Được - TTDVTH Phường Tân Khai
; =====================================================================

#define MyAppName "1Click Office - Chuẩn Hóa Văn Bản & Bảng Tính"
#define MyAppVersion "3.0 Enterprise"
#define MyAppPublisher "Trần Quốc Được - TTDVTH Phường Tân Khai"
#define MyAppExeName "1Click_Setup.exe"

[Setup]
AppId={{5D8E4A9B-1B44-469F-9C3E-81C5C77A1D20}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={userappdata}\1Click
DisableDirPage=yes
DisableProgramGroupPage=yes
OutputDir=G:\1Click Build\BoCaiDat_1Click
OutputBaseFilename=1Click_Setup
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
CloseApplications=yes
CloseApplicationsFilter=WINWORD.EXE,EXCEL.EXE
RestartApplications=no
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={userappdata}\Microsoft\Word\STARTUP\1Click.dotm

[Files]
Source: "1Click.dotm"; DestDir: "{userappdata}\Microsoft\Word\STARTUP"; Flags: ignoreversion
Source: "1Click_Excel.xlam"; DestDir: "{userappdata}\Microsoft\Excel\XLSTART"; Flags: ignoreversion
Source: "HuongDan_SuDung.txt"; DestDir: "{app}"; Flags: ignoreversion isreadme

[Registry]
; --- Cấu hình Trusted Locations cho Word (15.0 & 16.0) ---
Root: HKCU; Subkey: "Software\Microsoft\Office\15.0\Word\Security\Trusted Locations\1Click_WordStartup"; ValueType: string; ValueName: "Path"; ValueData: "{userappdata}\Microsoft\Word\STARTUP\"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Microsoft\Office\15.0\Word\Security\Trusted Locations\1Click_WordStartup"; ValueType: dword; ValueName: "AllowSubfolders"; ValueData: 1
Root: HKCU; Subkey: "Software\Microsoft\Office\15.0\Word\Security"; ValueType: dword; ValueName: "DisableAllAddins"; ValueData: 0
Root: HKCU; Subkey: "Software\Microsoft\Office\15.0\Word\Security"; ValueType: dword; ValueName: "AccessVBOM"; ValueData: 1

Root: HKCU; Subkey: "Software\Microsoft\Office\16.0\Word\Security\Trusted Locations\1Click_WordStartup"; ValueType: string; ValueName: "Path"; ValueData: "{userappdata}\Microsoft\Word\STARTUP\"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Microsoft\Office\16.0\Word\Security\Trusted Locations\1Click_WordStartup"; ValueType: dword; ValueName: "AllowSubfolders"; ValueData: 1
Root: HKCU; Subkey: "Software\Microsoft\Office\16.0\Word\Security"; ValueType: dword; ValueName: "DisableAllAddins"; ValueData: 0
Root: HKCU; Subkey: "Software\Microsoft\Office\16.0\Word\Security"; ValueType: dword; ValueName: "AccessVBOM"; ValueData: 1

; --- Cấu hình Trusted Locations cho Excel (15.0 & 16.0) ---
Root: HKCU; Subkey: "Software\Microsoft\Office\15.0\Excel\Security\Trusted Locations\1Click_ExcelStartup"; ValueType: string; ValueName: "Path"; ValueData: "{userappdata}\Microsoft\Excel\XLSTART\"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Microsoft\Office\15.0\Excel\Security\Trusted Locations\1Click_ExcelStartup"; ValueType: dword; ValueName: "AllowSubfolders"; ValueData: 1
Root: HKCU; Subkey: "Software\Microsoft\Office\15.0\Excel\Security"; ValueType: dword; ValueName: "DisableAllAddins"; ValueData: 0
Root: HKCU; Subkey: "Software\Microsoft\Office\15.0\Excel\Security"; ValueType: dword; ValueName: "AccessVBOM"; ValueData: 1

Root: HKCU; Subkey: "Software\Microsoft\Office\16.0\Excel\Security\Trusted Locations\1Click_ExcelStartup"; ValueType: string; ValueName: "Path"; ValueData: "{userappdata}\Microsoft\Excel\XLSTART\"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Microsoft\Office\16.0\Excel\Security\Trusted Locations\1Click_ExcelStartup"; ValueType: dword; ValueName: "AllowSubfolders"; ValueData: 1
Root: HKCU; Subkey: "Software\Microsoft\Office\16.0\Excel\Security"; ValueType: dword; ValueName: "DisableAllAddins"; ValueData: 0
Root: HKCU; Subkey: "Software\Microsoft\Office\16.0\Excel\Security"; ValueType: dword; ValueName: "AccessVBOM"; ValueData: 1

[InstallDelete]
; Xóa bỏ các bản cũ để tránh xung đột
Type: files; Name: "{userappdata}\Microsoft\Word\STARTUP\ChuanHoa_VanBanDang.dotm"
Type: files; Name: "{userappdata}\Microsoft\Excel\XLSTART\ChuanHoa_Excel.xlam"
Type: files; Name: "{userappdata}\Microsoft\Excel\XLSTART\*.bak"
Type: files; Name: "{userappdata}\Microsoft\Word\STARTUP\*.bak"

[UninstallDelete]
Type: files; Name: "{userappdata}\Microsoft\Word\STARTUP\1Click.dotm"
Type: files; Name: "{userappdata}\Microsoft\Excel\XLSTART\1Click_Excel.xlam"

[Code]
// Đóng Word và Excel an toàn trước khi cài đặt
function InitializeSetup(): Boolean;
var
  ErrorCode: Integer;
begin
  Result := True;
  ShellExec('open', 'taskkill.exe', '/F /IM WINWORD.EXE', '', SW_HIDE, ewWaitUntilTerminated, ErrorCode);
  ShellExec('open', 'taskkill.exe', '/F /IM EXCEL.EXE', '', SW_HIDE, ewWaitUntilTerminated, ErrorCode);
end;

// Mở khóa bảo mật file sau khi cài xong
procedure CurStepChanged(CurStep: TSetupStep);
var
  WordTarget, ExcelTarget: String;
  ErrorCode: Integer;
begin
  if CurStep = ssPostInstall then
  begin
    WordTarget := ExpandConstant('{userappdata}\Microsoft\Word\STARTUP\1Click.dotm');
    if FileExists(WordTarget) then
    begin
      ShellExec('open', 'powershell.exe', 
        '-NoProfile -ExecutionPolicy Bypass -Command "Unblock-File -Path ''' + WordTarget + '''"', 
        '', SW_HIDE, ewWaitUntilTerminated, ErrorCode);
    end;

    ExcelTarget := ExpandConstant('{userappdata}\Microsoft\Excel\XLSTART\1Click_Excel.xlam');
    if FileExists(ExcelTarget) then
    begin
      ShellExec('open', 'powershell.exe', 
        '-NoProfile -ExecutionPolicy Bypass -Command "Unblock-File -Path ''' + ExcelTarget + '''"', 
        '', SW_HIDE, ewWaitUntilTerminated, ErrorCode);
    end;
  end;
end;
