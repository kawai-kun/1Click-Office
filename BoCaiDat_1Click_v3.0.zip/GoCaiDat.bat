﻿@echo off
chcp 65001 >nul
cls
echo =====================================================================
echo           GỠ BỎ BỘ ADD-IN 1CLICK OFFICE (WORD & EXCEL)
echo             Tác giả: Trần Quốc Được - TTDVTH Phường Tân Khai
echo =====================================================================
echo.

set "WORD_TARGET=%APPDATA%\Microsoft\Word\STARTUP\1Click.dotm"
set "EXCEL_TARGET=%APPDATA%\Microsoft\Excel\XLSTART\1Click_Excel.xlam"

echo [*] Dang dong Microsoft Word va Excel...
taskkill /F /IM WINWORD.EXE >nul 2>&1
taskkill /F /IM EXCEL.EXE >nul 2>&1

if exist "%WORD_TARGET%" (
    del /F /Q "%WORD_TARGET%" >nul 2>&1
    echo [+] Da xoa bo 1Click.dotm khoi Word STARTUP!
)

if exist "%EXCEL_TARGET%" (
    del /F /Q "%EXCEL_TARGET%" >nul 2>&1
    echo [+] Da xoa bo 1Click_Excel.xlam khoi Excel XLSTART!
)

echo.
echo Da go bo thanh cong bo Add-in 1Click Office khoi may tinh!
echo.
pause
