﻿@echo off
chcp 65001 >nul
cls
echo =====================================================================
echo      BỘ CÀI ĐẶT ADD-IN 1CLICK OFFICE ENTERPRISE (WORD & EXCEL)
echo                      Phiên bản 3.0 Enterprise
echo             Tác giả: Trần Quốc Được - TTDVTH Phường Tân Khai
echo =====================================================================
echo.

set "SCRIPT_DIR=%~dp0"
set "WORD_SOURCE=%SCRIPT_DIR%1Click.dotm"
set "WORD_TARGET=%APPDATA%\Microsoft\Word\STARTUP"
set "EXCEL_SOURCE=%SCRIPT_DIR%1Click_Excel.xlam"
set "EXCEL_TARGET=%APPDATA%\Microsoft\Excel\XLSTART"

echo [*] Dang kiem tra va dong Microsoft Word, Excel neu dang mo...
taskkill /F /IM WINWORD.EXE >nul 2>&1
taskkill /F /IM EXCEL.EXE >nul 2>&1

echo [*] Go bo cac ban cu neu co de tranh xung dot...
if exist "%WORD_TARGET%\ChuanHoa_VanBanDang.dotm" del /F /Q "%WORD_TARGET%\ChuanHoa_VanBanDang.dotm" >nul 2>&1
if exist "%EXCEL_TARGET%\ChuanHoa_Excel.xlam" del /F /Q "%EXCEL_TARGET%\ChuanHoa_Excel.xlam" >nul 2>&1

echo [*] Dang cai dat Add-in 1Click vao Word STARTUP...
if not exist "%WORD_TARGET%" mkdir "%WORD_TARGET%" 2>nul
copy /Y "%WORD_SOURCE%" "%WORD_TARGET%\1Click.dotm" >nul

echo [*] Dang cai dat Add-in 1Click vao Excel XLSTART...
if not exist "%EXCEL_TARGET%" mkdir "%EXCEL_TARGET%" 2>nul
copy /Y "%EXCEL_SOURCE%" "%EXCEL_TARGET%\1Click_Excel.xlam" >nul

if not exist "%WORD_TARGET%\1Click.dotm" (
    echo [!] LOI: Khong the sao chep file 1Click.dotm vao Word!
    pause
    exit /b 1
)

if not exist "%EXCEL_TARGET%\1Click_Excel.xlam" (
    echo [!] LOI: Khong the sao chep file 1Click_Excel.xlam vao Excel!
    pause
    exit /b 1
)

echo [*] Mo khoa bao mat (Unblock File)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Unblock-File -Path '%WORD_TARGET%\1Click.dotm'; Unblock-File -Path '%EXCEL_TARGET%\1Click_Excel.xlam'" >nul 2>&1

echo [*] Dang cau hinh quyen tin cay (Trusted Locations) cho Word va Excel...
for %%V in (14.0 15.0 16.0) do (
    reg add "HKCU\Software\Microsoft\Office\%%V\Word\Security\Trusted Locations\1Click_WordStartup" /v "Path" /t REG_SZ /d "%WORD_TARGET%\" /f >nul 2>&1
    reg add "HKCU\Software\Microsoft\Office\%%V\Word\Security\Trusted Locations\1Click_WordStartup" /v "AllowSubfolders" /t REG_DWORD /d 1 /f >nul 2>&1
    reg add "HKCU\Software\Microsoft\Office\%%V\Word\Security" /v "DisableAllAddins" /t REG_DWORD /d 0 /f >nul 2>&1
    reg add "HKCU\Software\Microsoft\Office\%%V\Word\Security" /v "AccessVBOM" /t REG_DWORD /d 1 /f >nul 2>&1

    reg add "HKCU\Software\Microsoft\Office\%%V\Excel\Security\Trusted Locations\1Click_ExcelStartup" /v "Path" /t REG_SZ /d "%EXCEL_TARGET%\" /f >nul 2>&1
    reg add "HKCU\Software\Microsoft\Office\%%V\Excel\Security\Trusted Locations\1Click_ExcelStartup" /v "AllowSubfolders" /t REG_DWORD /d 1 /f >nul 2>&1
    reg add "HKCU\Software\Microsoft\Office\%%V\Excel\Security" /v "DisableAllAddins" /t REG_DWORD /d 0 /f >nul 2>&1
    reg add "HKCU\Software\Microsoft\Office\%%V\Excel\Security" /v "AccessVBOM" /t REG_DWORD /d 1 /f >nul 2>&1
    reg add "HKCU\Software\Microsoft\Office\%%V\Excel\Security" /v "VBAWarnings" /t REG_DWORD /d 1 /f >nul 2>&1
)

echo.
echo =====================================================================
echo              CÀI ĐẶT 1CLICK OFFICE THÀNH CÔNG!
echo =====================================================================
echo.
echo 1. TRONG MICROSOFT WORD:
echo    - Xuất hiện thẻ Ribbon: [THỂ THỨC VĂN BẢN] (và nút nhanh tab Home)
echo    - Chuẩn hóa thể thức tự động (Đảng, Chính quyền, Đoàn thể...)
echo    - Tạo văn bản mẫu đầy đủ (Tờ trình, Báo cáo, Kế hoạch, Quyết định...)
echo.
echo 2. TRONG MICROSOFT EXCEL:
echo    - Xuất hiện thẻ Ribbon: [CHUẨN HÓA IN] (và nút nhanh tab Home)
echo    - Chuẩn hóa trang in A4 vừa khít, căn giữa trang, lặp dòng tiêu đề
echo    - Xử lý họ tên: Viết hoa đầu từ, In hoa, Chữ thường, Xóa khoảng trắng
echo    - Tách cột Họ & Tên riêng biệt để sắp xếp A-Z danh sách
echo    - Đánh lại số thứ tự tự động (STT 1, 2, 3...)
echo    - Kẻ khung bảng biểu chuẩn văn bản hành chính, Xóa dòng trống
echo    - Đọc số tiền ra chữ (nút bấm hoặc dùng hàm =DocSo(ô) trực tiếp)
echo.
echo Tác giả: Trần Quốc Được - TTDVTH Phường Tân Khai
echo =====================================================================
echo.
pause
exit /b 0
